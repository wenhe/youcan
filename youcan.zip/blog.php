<?php

 /**
 * @fileName blog.php 
 * @extends for class JOB
 * @describe 一个用于完全展示动态学生的blog 
 * @package Example-application
 */

require './libs/index.php'; 


$index = new JOB();
$index->actionBlog();

?>
