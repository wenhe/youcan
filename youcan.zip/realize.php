<?php

 /**
 * @fileName require.php 
 * @extends for class JOB
 * @describe 帮助学生实现自己的idear
 * @package Example-application
 */

require './libs/index.php'; 


$index = new JOB();
$index->actionRealize();

?>
