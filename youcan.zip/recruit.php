<?php

 /**
 * @fileName recruit.php 
 * @extends for class JOB
 * @describe 为公司实现校园招聘 
 * @package Example-application
 */

require './libs/index.php'; 


$index = new JOB();
$index->actionRecruit();

?>
