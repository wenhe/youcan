<?php

 /**
 * @fileName idear.php 
 * @extends for class JOB
 * @describe 一个用于完全展示学生想法的平台 
 * @package Example-application
 */

require './libs/index.php'; 


$index = new JOB();
$index->actionIdear();

?>
