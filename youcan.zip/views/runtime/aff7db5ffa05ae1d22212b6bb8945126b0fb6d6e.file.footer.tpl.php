<?php /* Smarty version Smarty-3.1.13, created on 2013-03-30 23:44:16
         compiled from "/home/wwwroot/youcan/views/templates/base/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:180974627151570850868571-86531404%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aff7db5ffa05ae1d22212b6bb8945126b0fb6d6e' => 
    array (
      0 => '/home/wwwroot/youcan/views/templates/base/footer.tpl',
      1 => 1364614398,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '180974627151570850868571-86531404',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5157085086b627_33756734',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5157085086b627_33756734')) {function content_5157085086b627_33756734($_smarty_tpl) {?><h5> 版权信息 @ copyright</h5>
<?php }} ?>