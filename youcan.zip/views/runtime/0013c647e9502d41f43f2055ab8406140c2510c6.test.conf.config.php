<?php $_config_vars = array (
  'sections' => 
  array (
    'setup' => 
    array (
      'vars' => 
      array (
        'bold' => true,
      ),
    ),
  ),
  'vars' => 
  array (
    'title' => 'Welcome to Smarty!',
    'cutoff_size' => 40,
  ),
); ?>