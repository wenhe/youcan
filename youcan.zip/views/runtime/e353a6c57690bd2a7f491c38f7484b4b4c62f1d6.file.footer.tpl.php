<?php /* Smarty version Smarty-3.1.13, created on 2013-03-30 11:17:21
         compiled from "/home/wwwroot/thinkphp/views/templates/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2374423815156590f896736-28021284%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e353a6c57690bd2a7f491c38f7484b4b4c62f1d6' => 
    array (
      0 => '/home/wwwroot/thinkphp/views/templates/footer.tpl',
      1 => 1364613412,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2374423815156590f896736-28021284',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5156590f899b73_96806776',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5156590f899b73_96806776')) {function content_5156590f899b73_96806776($_smarty_tpl) {?></BODY>
</HTML>
<?php }} ?>