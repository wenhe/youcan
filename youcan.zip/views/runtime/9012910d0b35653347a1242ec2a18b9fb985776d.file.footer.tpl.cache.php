<?php /* Smarty version Smarty-3.1.13, created on 2013-03-30 10:53:24
         compiled from "./views/templates/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:147407041515653a4292e42-22512394%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9012910d0b35653347a1242ec2a18b9fb985776d' => 
    array (
      0 => './views/templates/footer.tpl',
      1 => 1364610820,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '147407041515653a4292e42-22512394',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_515653a4296c97_13971781',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_515653a4296c97_13971781')) {function content_515653a4296c97_13971781($_smarty_tpl) {?></BODY>
</HTML>
<?php }} ?>