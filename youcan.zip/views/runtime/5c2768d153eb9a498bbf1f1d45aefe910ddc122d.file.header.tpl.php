<?php /* Smarty version Smarty-3.1.13, created on 2013-03-30 11:16:31
         compiled from "/home/wwwroot/thinkphp/views/templates/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8360596215156590f885935-19544006%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5c2768d153eb9a498bbf1f1d45aefe910ddc122d' => 
    array (
      0 => '/home/wwwroot/thinkphp/views/templates/header.tpl',
      1 => 1364610820,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8360596215156590f885935-19544006',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5156590f889171_44647476',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5156590f889171_44647476')) {function content_5156590f889171_44647476($_smarty_tpl) {?><HTML>
<HEAD>
<TITLE>{$title} - {$Name}</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }} ?>