<?php /* Smarty version Smarty-3.1.13, created on 2013-03-30 10:53:24
         compiled from "./views/templates/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1930914729515653a41d3e82-32180100%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '23411182f38937b25e937eef6f3fc2c0fca668be' => 
    array (
      0 => './views/templates/header.tpl',
      1 => 1364610820,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1930914729515653a41d3e82-32180100',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'title' => 0,
    'Name' => 1,
  ),
  'has_nocache_code' => true,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_515653a42808e6_78390421',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_515653a42808e6_78390421')) {function content_515653a42808e6_78390421($_smarty_tpl) {?><HTML>
<HEAD>
<TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo '/*%%SmartyNocache:1930914729515653a41d3e82-32180100%%*/<?php echo $_smarty_tpl->tpl_vars[\'Name\']->value;?>
/*/%%SmartyNocache:1930914729515653a41d3e82-32180100%%*/';?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }} ?>