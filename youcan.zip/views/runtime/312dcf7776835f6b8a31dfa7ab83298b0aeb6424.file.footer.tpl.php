<?php /* Smarty version Smarty-3.1.13, created on 2013-03-30 11:54:30
         compiled from "/home/wwwroot/thinkphp/views/templates/base/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2117864349515661f67eaf42-35527479%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '312dcf7776835f6b8a31dfa7ab83298b0aeb6424' => 
    array (
      0 => '/home/wwwroot/thinkphp/views/templates/base/footer.tpl',
      1 => 1364614398,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2117864349515661f67eaf42-35527479',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_515661f67eebd8_58938330',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_515661f67eebd8_58938330')) {function content_515661f67eebd8_58938330($_smarty_tpl) {?><h5> 版权信息 @ copyright</h5>
<?php }} ?>