<?php /* Smarty version Smarty-3.1.13, created on 2013-03-30 22:59:46
         compiled from "/home/wwwroot/thinkphp/views/templates/base/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:198913147515661f6769af6-57493612%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd38bcf0e467938011ac3803bfeeccad73cae1167' => 
    array (
      0 => '/home/wwwroot/thinkphp/views/templates/base/header.tpl',
      1 => 1364655584,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '198913147515661f6769af6-57493612',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_515661f67e22a4_46390269',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_515661f67e22a4_46390269')) {function content_515661f67e22a4_46390269($_smarty_tpl) {?><h2> 这是一个有益于学生的一个开放平台  </h2>



	<ul>
	<li><a href='/index.php'>首页</a></li>
	<li><a href='/idear.php'>展示idear</a></li>
	<li><a href='/blog.php'>学生博客（简历）职位推荐</a></li>
	<li><a href='/realize.php'>帮助学生实现</a></li>
	<li><a href='/recruit.php'>学校招聘</a></li>
	</ul>
<?php }} ?>